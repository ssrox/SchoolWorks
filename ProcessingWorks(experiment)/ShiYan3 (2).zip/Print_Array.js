const arr = Array.from({ length: 20 }, (_, i) => i + 1);

for (let i = 0; i < arr.length; i++) {
  console.log(arr[i]);
}